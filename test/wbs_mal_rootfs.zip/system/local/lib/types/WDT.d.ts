/*
 * Windows 96 WDT Preprocessor declarations.
 *
 * Copyright (C) Windows 96 Team 2024.
 */

// IMPORTANT NOTE:
// ---------------
// These directives are handled differently by the preprocessor
// They are not traditional functions, do not treat them as such!
//
// All directives must start on an empty line.

/**
 * [WDT-Preproc]
 * 
 * Includes a file. Relative paths will resolve to the current directory.
 * @param path The path of the file to include.
 */
declare function $$Include(path: string): void;

/**
 * [WDT-Preproc]
 * 
 * Same as `$$Include`, except it makes sure the file is only included once globally.
 * @param path The path of the file to include.
 */
declare function $$IncludeOnce(path: string): void;

/**
 * [WDT-Preproc]
 * 
 * Define a directive. To use it, use `$[("DirectiveName")]` in code.
 * @param name The name of the directive to define.
 * @param value The value to set.
 */
declare function $$Define(name: string, value?: string): void;

/**
 * [WDT-Preproc]
 * 
 * Undefines a directive.
 * @param name The name of the directive to undefine.
 */
declare function $$Undef(name: string): void;