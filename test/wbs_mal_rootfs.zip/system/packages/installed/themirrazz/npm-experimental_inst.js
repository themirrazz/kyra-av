w96.sys.execCmd('terminal',['npm', 'help', 'npm'])

setTimeout(function () {
    alert(
        "NPM IS EXPERIMETNAL\n\nThere may be bugs. There <i>WILL</i>be bugs. If you find something that's not supposed to happen, please open an issue at https://github.com/themirrazz/node96"
    );
}, 1000);