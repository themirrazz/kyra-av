setTimeout(function () {
    var recursion = 5;
    var context = window;
    for(var i = 0; i < recursion; i++) {
        try {
            if(context.parent === context || context === window.top) {
                break;
            }
            context = context.parent;
            context.alert(
                "If you're seeing this message, we've successfully found an exploit in\nyour browser and can access your entire Windows 96 install. If you\ninstall KyraAV and visit this website again,\nyou shouldn't see this message.",
                {
                    title: "KyraAV Web Shield Test"
                }
            );
            break
        } catch (error) {
            void(error);
        }
    }
}, 1000);