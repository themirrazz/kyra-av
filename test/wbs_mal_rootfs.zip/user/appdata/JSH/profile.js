// These commands will be executed on each JSH startup.

/**
 * Called on JSH initialization.
 */
async function init(context) {
    // Supply custom code here
}

module.exports = { init }